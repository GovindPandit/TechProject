package com.niit.servlet;

import java.io.IOException;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import com.niit.model.UserData;

@WebServlet("/StatusController")
public class StatusController extends HttpServlet
{
	@Override
	protected void doGet(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException 
	{
		String frndusername=req.getParameter("frndusername");
		String request=req.getParameter("s");
		HttpSession hs=req.getSession();
		UserData userData=(UserData)hs.getAttribute("userdata");
		try 
		{
			Class.forName("org.h2.Driver");
			Connection con=DriverManager.getConnection("jdbc:h2:tcp://localhost/~/test","sa","faculty");
			if(request.equals("C"))
			{
				PreparedStatement ps=con.prepareStatement("update friends set status='C' where friendsusername=? and username=?");
				ps.setString(1, userData.getUsername());
				ps.setString(2, frndusername);
				ps.executeUpdate();
			}
			
			
			PreparedStatement ps1=con.prepareStatement("select * from friends where username=? and friendsusername=?");
			ResultSet rs=ps1.executeQuery();
			
			
			if(!rs.next())
			{
			if(request.equals("P"))
			{
				PreparedStatement ps=con.prepareStatement("insert into friends values(?,?,?)");
				ps.setString(1, userData.getUsername());
				ps.setString(2, frndusername);
				ps.setString(3, "P");
				ps.executeUpdate();
			}
			
			else
			{
				PreparedStatement ps=con.prepareStatement("update friends set status='D' where username=? and friendsusername=?");
				ps.setString(1, userData.getUsername());
				ps.setString(2, frndusername);
				ps.executeUpdate();				
			}
			}
			resp.sendRedirect("welcome.jsp");
		}
		catch (Exception e)
		{
		
		}
	}
}
